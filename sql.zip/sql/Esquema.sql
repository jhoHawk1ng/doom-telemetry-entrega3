R(Cod_Empleado, Nombre_Empleado, Cod_Departamento, Nombre_Departamento, Proyecto, Horas, Localización)
